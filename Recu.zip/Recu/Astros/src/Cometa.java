public class Cometa extends Astro implements ModificadorOrbita {
    private final double periodoOrbital;

    public Cometa(String nombre, String region, TipoRadiacion tipoDeRadiacion, double periodoOrbital) {
        super(nombre, region, tipoDeRadiacion);
        this.periodoOrbital = periodoOrbital;
    }

    public double getPeriodoOrbital() {
        return periodoOrbital;
    }

    @Override
    public void modificarOrbita() throws AstroException {
        throw new AstroException("ÉXITO: El cometa " + getNombre() + " modificó su órbita.");
    }

    @Override
    public String toString() {
        return "[Cometa] " + super.toString() + 
               ", Período Orbital: " + periodoOrbital + " años";
    }
}