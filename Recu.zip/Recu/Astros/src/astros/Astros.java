/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package astros;

/**
 *
 * @author Mariano
 */
public class Astros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
public class Astros {

    public static void main(String[] args) {
        System.out.println("Iniciando Sistema de Registro de Astros...");
        EstacionDeObservacion estacion = new EstacionDeObservacion();

        // Creación de Astros
        Astro estrella1 = new Estrella("Helion", "Sector A", TipoRadiacion.ULTRAVIOLETA, 5778);
        Astro planeta1 = new Planeta("Tierra", "Sector A", TipoRadiacion.INFRARROJA, true);
        Astro cometa1 = new Cometa("Halley", "Sector B", TipoRadiacion.RAYOS_X, 76.0);
        Astro estrella2 = new Estrella("Sirio", "Sector B", TipoRadiacion.ULTRAVIOLETA, 9940);
        
        // Escenario 1: Registrar Astros
        System.out.println("\n--- Escenario 1: Registrando Astros ---");
        try {
            estacion.agregarAstro(estrella1);
            estacion.agregarAstro(planeta1);
            estacion.agregarAstro(cometa1);
            estacion.agregarAstro(estrella2);

            System.out.println("\nIntentando agregar astro duplicado...");
            Astro estrellaDuplicada = new Estrella("Helion", "Sector A", TipoRadiacion.RAYOS_X, 1234);
            estacion.agregarAstro(estrellaDuplicada);
            
        } catch (AstroException e) {
            System.out.println(e.getMessage());
        }

        try {
            System.out.println("\nIntentando agregar astro nulo...");
            estacion.agregarAstro(null);
        } catch (AstroException e) {
            System.out.println(e.getMessage());
        }

        // Escenario 2: Mostrar Astros
        estacion.mostrarAstros();

        // Escenario 3: Generar Campos Magnéticos
        estacion.generarCamposMagneticos();

        // Escenario 4: Modificar Órbitas
        estacion.modificarOrbitas();

        // Escenario 5: Filtrar por Tipo de Radiación
        estacion.filtrarPorTipoRadiacion(TipoRadiacion.ULTRAVIOLETA);

        // Escenario 6: Filtrar por Tipo de Astro
        estacion.filtrarPorTipoDeAstro("Planeta");
        
        System.out.println("\n--- Simulación Finalizada ---");
    }
}