public enum TipoRadiacion {
    INFRARROJA,
    ULTRAVIOLETA,
    RAYOS_X
}