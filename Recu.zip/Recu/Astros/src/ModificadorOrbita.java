public interface ModificadorOrbita {
    void modificarOrbita() throws AstroException;
}