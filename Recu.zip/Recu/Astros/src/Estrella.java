public class Estrella extends Astro implements GeneradorCampoMagnetico, ModificadorOrbita {
    private final double temperaturaSuperficial;

    public Estrella(String nombre, String region, TipoRadiacion tipoDeRadiacion, double temperaturaSuperficial) {
        super(nombre, region, tipoDeRadiacion);
        this.temperaturaSuperficial = temperaturaSuperficial;
    }

    public double getTemperaturaSuperficial() {
        return temperaturaSuperficial;
    }

    @Override
    public void generarCampoMagnetico() throws AstroException {
        throw new AstroException("ÉXITO: La estrella " + getNombre() + " generó un campo magnético.");
    }

    @Override
    public void modificarOrbita() throws AstroException {
        throw new AstroException("ÉXITO: La estrella " + getNombre() + " modificó su órbita.");
    }

    @Override
    public String toString() {
        return "[Estrella] " + super.toString() + 
               ", Temp. Superficial: " + temperaturaSuperficial + " K";
    }
}