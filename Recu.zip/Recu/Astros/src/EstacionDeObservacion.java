import java.util.ArrayList;

public class EstacionDeObservacion {
    private ArrayList<Astro> astros;

    public EstacionDeObservacion() {
        this.astros = new ArrayList<>();
    }

    public void agregarAstro(Astro a) throws AstroException {
        if (a == null) {
            throw new AstroException("Error: No se puede agregar un astro nulo.");
        }
        
        if (astros.contains(a)) {
            throw new AstroException("Error: Ya existe un astro con el nombre '" + 
                a.getNombre() + "' en la región '" + a.getRegion() + "'.");
        }
        astros.add(a);
        System.out.println("Info: " + a.getNombre() + " fue agregado exitosamente.");
    }

    public void mostrarAstros() {
        System.out.println("\n--- Lista de Astros Registrados ---");
        if (astros.isEmpty()) {
            System.out.println("No hay astros registrados.");
            return;
        }
        for (Astro astro : astros) {
            System.out.println(astro.toString());
        }
        System.out.println("------------------------------------");
    }

    public void generarCamposMagneticos() {
        System.out.println("\n--- Generando Campos Magnéticos ---");
        for (Astro astro : astros) {
            if (astro instanceof GeneradorCampoMagnetico generadorCampoMagnetico) {
                try {
                    generadorCampoMagnetico.generarCampoMagnetico();
                } catch (AstroException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        System.out.println("-------------------------------------");
    }

    public void modificarOrbitas() {
        System.out.println("\n--- Modificando Órbitas ---");
        for (Astro astro : astros) {
            if (astro instanceof ModificadorOrbita modificadorOrbita) {
                try {
                    modificadorOrbita.modificarOrbita();
                } catch (AstroException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        System.out.println("-----------------------------");
    }

    public void filtrarPorTipoRadiacion(TipoRadiacion tipo) {
        System.out.println("\n--- Astros con Radiación: " + tipo + " ---");
        int count = 0;
        for (Astro astro : astros) {
            if (astro.getTipoDeRadiacion() == tipo) {
                System.out.println(astro);
                count++;
            }
        }
        if (count == 0) {
            System.out.println("No se encontraron astros con ese tipo de radiación.");
        }
        System.out.println("-------------------------------------------");
    }

    public void filtrarPorTipoDeAstro(String tipoAstro) {
        System.out.println("\n--- Filtro por Tipo de Astro: " + tipoAstro + " ---");
        int count = 0;
        for (Astro astro : astros) {
            
            if (tipoAstro.equalsIgnoreCase("Estrella") && astro instanceof Estrella) {
                System.out.println(astro);
                count++;
            } else if (tipoAstro.equalsIgnoreCase("Planeta") && astro instanceof Planeta) {
                System.out.println(astro);
                count++;
            } else if (tipoAstro.equalsIgnoreCase("Cometa") && astro instanceof Cometa) {
                System.out.println(astro);
                count++;
            }
        }
        if (count == 0) {
            System.out.println("No se encontraron astros de tipo '" + tipoAstro + "'.");
        }
        System.out.println("-------------------------------------------");
    }
}