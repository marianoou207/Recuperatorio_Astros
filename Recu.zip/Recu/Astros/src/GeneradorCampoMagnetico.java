public interface GeneradorCampoMagnetico {
    void generarCampoMagnetico() throws AstroException;
}