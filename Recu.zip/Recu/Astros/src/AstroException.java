public class AstroException extends Exception {
    public AstroException(String message) {
        super(message);
    }
}