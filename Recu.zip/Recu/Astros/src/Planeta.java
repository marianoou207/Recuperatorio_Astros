public class Planeta extends Astro implements GeneradorCampoMagnetico {
    private final boolean poseeAtmosfera;

    public Planeta(String nombre, String region, TipoRadiacion tipoDeRadiacion, boolean poseeAtmosfera) {
        super(nombre, region, tipoDeRadiacion);
        this.poseeAtmosfera = poseeAtmosfera;
    }

    public boolean isPoseeAtmosfera() {
        return poseeAtmosfera;
    }

    @Override
    public void generarCampoMagnetico() throws AstroException {
        throw new AstroException("ÉXITO: El planeta " + getNombre() + " generó un campo magnético.");
    }

    @Override
    public String toString() {
        return "[Planeta] " + super.toString() + 
               ", ¿Tiene Atmósfera?: " + (poseeAtmosfera ? "Sí" : "No");
    }
}