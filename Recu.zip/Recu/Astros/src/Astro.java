public abstract class Astro {
    private final String nombre;
    private final String region;
    private final TipoRadiacion tipoDeRadiacion;

    public Astro(String nombre, String region, TipoRadiacion tipoDeRadiacion) {
        this.nombre = nombre;
        this.region = region;
        this.tipoDeRadiacion = tipoDeRadiacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRegion() {
        return region;
    }

    public TipoRadiacion getTipoDeRadiacion() {
        return tipoDeRadiacion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Astro astro = (Astro) o;
        return nombre.equalsIgnoreCase(astro.nombre) &&
               region.equalsIgnoreCase(astro.region);
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + 
               ", Región: " + region + 
               ", Radiación: " + tipoDeRadiacion;
    }
}